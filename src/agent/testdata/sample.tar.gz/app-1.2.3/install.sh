#!/bin/sh
set -e
cp bin/app /usr/local/bin/
